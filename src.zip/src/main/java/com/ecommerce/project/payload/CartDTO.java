package com.ecommerce.project.payload;

import com.ecommerce.project.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartDTO {

    private Long cartId;
    private double totalPrice;
    //private UserDTO user;
    private List<CartItemDTO> cartItems  = new ArrayList<>();
}
